document.addEventListener('DOMContentLoaded', function() {
    const userTypeSelect = document.getElementById('userType');
    const patientIdContainer = document.getElementById('patientIdContainer');
    const practiceRegNumberContainer = document.getElementById('practiceRegNumberContainer');
    const registerForm = document.getElementById('registerForm');
    const medicationResults = document.getElementById('medicationResults');
    const medicalFileInput = document.getElementById('medicalFileInput');
    const medicalResultsContainer = document.getElementById('medicalResultsContainer');
    const aiResults = document.getElementById('aiResults');

    // Function to update the display based on user type
    function updateUserTypeDisplay() {
        const isPatient = userTypeSelect.value === 'patient';
        patientIdContainer.style.display = isPatient ? 'block' : 'none';
        practiceRegNumberContainer.style.display = isPatient ? 'none' : 'block';
        document.getElementById('patientId').required = isPatient;
        document.getElementById('practiceRegNumber').required = !isPatient;
    }

    userTypeSelect.addEventListener('change', updateUserTypeDisplay);
    updateUserTypeDisplay();

    // Function to validate password
    function validatePassword(password, name) {
        const minPasswordLength = 8;
        const recentPasswords = []; // Should be fetched from backend
        const nameParts = name.split(' ');

        for (const part of nameParts) {
            if (part.length > 2 && password.includes(part)) {
                alert('Password must not contain parts of your name.');
                return false;
            }
        }

        if (password.length < minPasswordLength) {
            alert('Password must be at least 8 characters long.');
            return false;
        }

        if (recentPasswords.includes(password)) {
            alert('You cannot reuse a password that has been used before.');
            return false;
        }

        const hasUpperCase = /[A-Z]/.test(password);
        const hasLowerCase = /[a-z]/.test(password);
        const hasDigit = /\d/.test(password);
        const hasNonAlpha = /[^a-zA-Z0-9]/.test(password);

        const complexityCount = [hasUpperCase, hasLowerCase, hasDigit, hasNonAlpha].filter(Boolean).length;
        if (complexityCount < 3) {
            alert('Password must contain characters from three of the following categories: uppercase letters, lowercase letters, digits, non-alphabetic characters.');
            return false;
        }

        return true;
    }

    // Function to handle file upload
    function handleFileUpload() {
        const file = medicalFileInput.files[0];
        if (file) {
            alert(`File ${file.name} selected for upload.`);
            // Implement the file upload logic here
        } else {
            alert('No file selected.');
        }
    }

    // Function to handle file scan
    function handleFileScan() {
        alert('Scanning document...');
        // Implement the document scanning logic here
        document.getElementById('scanResults').innerText = 'Document scan complete. Results displayed here.';
    }

    // Function to check medication availability
    function checkMedicationAvailability() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                const latitude = position.coords.latitude;
                const longitude = position.coords.longitude;

                fetch(`https://api.example.com/medications?lat=${latitude}&lon=${longitude}`)
                    .then(response => response.json())
                    .then(data => {
                        displayMedicationResults(data);
                    })
                    .catch(error => {
                        medicationResults.innerText = 'Failed to fetch medication data.';
                        console.error('Error fetching medication data:', error);
                    });
            }, function() {
                medicationResults.innerText = 'Geolocation is not supported or permission denied.';
            });
        } else {
            medicationResults.innerText = 'Geolocation is not supported by this browser.';
        }
    }

    // Function to display medication results
    function displayMedicationResults(data) {
        if (data && data.length > 0) {
            medicationResults.innerHTML = `<h4>Medication Availability:</h4><ul>${data.map(item => `<li>${item.name}: ${item.availability}</li>`).join('')}</ul>`;
        } else {
            medicationResults.innerText = 'No medication data available.';
        }
    }

    // Function to handle patient search
    function searchPatient() {
        const patientId = document.getElementById('patientIdSearch').value;

        if (patientId.trim() === '') {
            alert('Please enter a Patient ID.');
            return;
        }

        // Simulate fetching data based on Patient ID
        fetch(`https://api.example.com/patients/${patientId}/medicalResults`)
            .then(response => response.json())
            .then(data => {
                displayMedicalResults(data);
                interpretResultsWithAI(data);
            })
            .catch(error => {
                medicalResultsContainer.innerText = 'Failed to fetch medical data.';
                console.error('Error fetching medical data:', error);
            });
    }

    // Function to display fetched medical results
    function displayMedicalResults(data) {
        medicalResultsContainer.innerHTML = `
            <h4>Medical Results for Patient ID: ${data.patientId}</h4>
            <ul>${data.results.map(item => `<li>${item.testName}: ${item.value} ${item.unit}</li>`).join('')}</ul>
        `;
    }

    // Function to interpret results using AI
    function interpretResultsWithAI(data) {
        const aiInterpretation = "AI-generated interpretation based on the fetched results.";

        // Example of appending AI insights
        aiResults.innerHTML = `
            <h4>AI-Generated Insights:</h4>
            <p>${aiInterpretation}</p>
        `;
    }

    // Function to ask AI a question based on results
    function askQuestion() {
        const question = prompt('What would you like to ask the AI?');
        if (question) {
            aiResults.innerHTML += `<p><strong>Q:</strong> ${question}</p><p><strong>A:</strong> AI-generated answer based on the question.</p>`;
        }
    }

    // Function to search for medication availability
    function searchMedication() {
        // Implement the logic to search for medication availability
        // This could involve sending a request to a server or API
    }

    // Function to use the current location for searching medication
    function useCurrentLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                position => {
                    const latitude = position.coords.latitude;
                    const longitude = position.coords.longitude;
                    // Use latitude and longitude for location-based search
                },
                error => {
                    alert('Error getting location: ' + error.message);
                }
            );
        } else {
            alert('Geolocation is not supported by this browser.');
        }
    }

    // Function to get support
    function getSupport() {
        // Implement the logic to get support
    }

    // Function to handle logout
    function logout() {
        sessionStorage.clear();
        window.location.href = 'login.html';
    }

    // Navigation functions
    function editProfile() {
        window.location.href = 'editProfile.html';
    }

    function viewAppointments() {
        window.location.href = 'viewAppointments.html';
    }

    function recordMedicalResults() {
        window.location.href = 'recordMedicalResults.html';
    }

    function viewMedicalResults() {
        window.location.href = 'viewMedicalResults.html';
    }

    function meetPatient() {
        window.location.href = 'meetPatient.html';
    }

    function getSupport() {
        window.location.href = 'support.html';
    }

    function logout() {
        sessionStorage.clear();
        window.location.href = 'login.html';
    }
	
	function medicationPrescription() {
        sessionStorage.clear();
        window.location.href = 'medicationPrescription.html';
    }

    // Form submission handling
    registerForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const userType = userTypeSelect.value.toLowerCase();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;
        const patientId = document.getElementById('patientId').value;
        const practiceRegNumber = document.getElementById('practiceRegNumber').value;

        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        if (!validatePassword(password, name)) {
            return;
        }

        if (userType === 'patient') {
            if (!patientId) {
                alert('Patient ID is required.');
                return;
            }
            window.location.href = `Patient.html?name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&phone=${encodeURIComponent(phone)}&patientId=${encodeURIComponent(patientId)}`;
        } else if (userType === 'practitioner') {
            if (!practiceRegNumber) {
                alert('Practice Registration Number is required.');
                return;
            }
            window.location.href = `Practitioner.html?name=${encodeURIComponent(name)}&email=${encodeURIComponent(email)}&phone=${encodeURIComponent(phone)}&practiceRegNumber=${encodeURIComponent(practiceRegNumber)}`;
        }
    });

    // Add event listeners for actions
    document.querySelector('#fileUploadContainer button[onclick="uploadMedicalFile()"]').addEventListener('click', handleFileUpload);
    document.querySelector('#fileUploadContainer button[onclick="scanMedicalDocument()"]').addEventListener('click', handleFileScan);
    document.querySelector('button[onclick="editProfile()"]').addEventListener('click', editProfile);
    document.querySelector('button[onclick="viewAppointments()"]').addEventListener('click', viewAppointments);
    document.querySelector('button[onclick="recordMedicalResults()"]').addEventListener('click', recordMedicalResults);
    document.querySelector('button[onclick="viewMedicalResults()"]').addEventListener('click', viewMedicalResults);
	document.querySelector('button[onclick="viewMedicalResults()"]').addEventListener('click', viewMedicalResults);
    document.querySelector('button[onclick="checkMedicationAvailability()"]').addEventListener('click', checkMedicationAvailability);
    document.querySelector('button[onclick="meetPatient()"]').addEventListener('click', meetPatient);
    document.querySelector('button[onclick="getSupport()"]').addEventListener('click', getSupport);
    document.querySelector('button.logout').addEventListener('click', logout);
    document.querySelector('button[onclick="searchPatient()"]').addEventListener('click', searchPatient);
    document.querySelector('button[onclick="askQuestion()"]').addEventListener('click', askQuestion);
    document.querySelector('button[onclick="searchMedication()"]').addEventListener('click', searchMedication);
    document.querySelector('button[onclick="useCurrentLocation()"]').addEventListener('click', useCurrentLocation);
	document.querySelector('button[onclick="medicationPrescription()"]').addEventListener('click', medicationPrescription);
	
	function submitRating() {
    const practitioner = document.getElementById('practitionerSelect').value;
    const rating = document.querySelector('input[name="rating"]:checked');
    const feedback = document.getElementById('feedback').value;

    if (!practitioner || !rating || !feedback) {
        alert('Please fill out all sections before submitting.');
        return;
    }

    // Simulate form submission
    console.log('Practitioner:', practitioner);
    console.log('Rating:', rating.value);
    console.log('Feedback:', feedback);

    // Display thank you message
    document.getElementById('thankYouMessage').classList.remove('hidden');

    // Clear form
    document.getElementById('practitionerSelect').value = '';
    rating.checked = false;
    document.getElementById('feedback').value = '';
}
  function sendMessage() {
            const userInput = document.getElementById("userInput").value;
            if (userInput.trim() === "") return;
            
            const chatLog = document.getElementById("chat-log");

            // Display user's message
            const userMessage = document.createElement("div");
            userMessage.className = "user-message";
            userMessage.textContent = "You: " + userInput;
            chatLog.appendChild(userMessage);
            document.getElementById("userInput").value = "";

            // Simulate AI response
            const aiMessage = document.createElement("div");
            aiMessage.className = "ai-message";
            aiMessage.textContent = "AI: Thinking...";

            chatLog.appendChild(aiMessage);
            chatLog.scrollTop = chatLog.scrollHeight;  // Auto scroll to the bottom

            // Simulate a delay for AI response
            setTimeout(() => {
                aiMessage.textContent = "AI: This is a simulated response to '" + userInput + "'.";
                chatLog.scrollTop = chatLog.scrollHeight;
            }, 1000);
        }
	function scanPrescription() {
            // Functionality to scan prescription using device camera
            // This would involve accessing the device camera and capturing an image
            // Implementation may vary depending on the camera API or library used
            alert('Scan functionality to be implemented');
        }
});